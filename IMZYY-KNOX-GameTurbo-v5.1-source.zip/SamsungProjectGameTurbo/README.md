# IMZYY KNOX GAME TURBO v4.1 — Premium Performance Suite

## Upgrade v4.0
- Refined dark premium interface and typography.
- FPS precision slider in the main app and floating hub; target is resolved to a refresh mode supported by the display.
- Floating hub uses a bounded scrollable panel with improved spacing.
- Render profiles: System Default, Compatibility, Performance. These are saved preferences only; they do not force another game's internal renderer.
- Smart toggles: frame-rate preference, thermal guard preference, battery balance, touch response preference, and saved game profile.
- Permission prompts for overlay, write system settings, and notifications are not repeatedly launched. If the user declines, the app shows a reminder rather than reopening Settings on every action.

## Honest Android limitations
A normal third-party app cannot force another game's internal FPS cap, switch its Vulkan/OpenGL renderer, overclock CPU/GPU, change governors, or modify touch sampling. FPS slider chooses a display refresh mode supported by the device. Some requested values are rounded to the nearest supported mode.

The thermal, battery, touch, and frame toggles are preference/profile switches and explanatory controls; they do not claim privileged hardware changes. Live sensor values remain sourced from Android APIs.


## Upgrade v4.1
- Added selectable display profiles: System Auto, Compatibility (lowest supported display mode), Balanced (nearest supported to 60 Hz), and Performance (highest supported display mode).
- Added APPLY DISPLAY PROFILE actions in the main screen and floating hub. If needed, the app opens Android's per-app **Modify system settings** permission screen. The user must approve it manually.
- Floating bubble and panel now reflow after portrait/landscape changes: bubble snaps to the nearest side and stays within the visible screen; panel width, height, and position are recalculated.
- This changes supported display refresh settings only. A regular app cannot force another game's internal renderer, GPU/CPU overclock, or graphics API.

## Upgrade v4.2 — Graphics Experience + Animated UI
- Added saved graphics presets: Smart Auto, Ultra Clarity, Balanced, Performance, and Thermal Safe.
- Added clear in-app guidance for texture, shadow, effects, resolution, and thermal choices.
- Added graphic profile controls to both the main app and floating hub.
- Added staggered screen entrance animations, subtle turbo-button breathing animation, and animated button feedback.
- Version bumped to 4.2.

### Graphics capability note
Android apps without privileged/root access cannot directly rewrite another game's texture quality, shader settings, internal resolution, Vulkan/OpenGL renderer, or GPU clocks. These presets save a profile, offer practical in-game recommendations, and can select a supported display refresh rate. They do not pretend to modify a game's private graphics engine.


## Upgrade v4.3 — Functional controls
- Frame Rate Optimization applies the highest supported display refresh mode and resets to system auto when disabled.
- Battery Balance lowers screen brightness and applies a 60 Hz-or-nearest display mode; it restores saved brightness when disabled. Requires Android Modify system settings permission.
- Thermal Guard blocks the app's RAM/cache boost action when battery temperature is at least 40°C. It does not cool the chipset or control CPU/GPU clocks.
- Touch Response opens Android Display settings so users can enable Samsung Touch sensitivity when exposed; the app cannot change touch sampling rate.
- Smart Game Profile is a real game picker with saved-game launch action.
- Graphics presets apply a supported display refresh mode; texture, shadows, shaders, internal resolution and GPU clocks remain controlled by the game/Android firmware.
- Floating Hub uses the same functional profile actions.

### Test notes
Source-level changes only. Build and device testing are still required. Permission-dependent features must be granted by the user in Android Settings.


## Upgrade v4.4 — Compact Dashboard + Movable Floating Hub
- Main dashboard uses expandable cards: hero and live status remain visible, other menus start folded and expand on tap.
- Card headers show a chevron and animate on interaction, reducing the initial page length.
- Floating Hub is resized to a compact, screen-relative window with a wider usable layout.
- Floating Hub can be dragged by its header and is clamped to screen bounds; the floating bubble remains draggable and snaps to the nearest screen edge.
- This is a UI/interaction update; it does not add privileged GPU or game-renderer controls.


## Upgrade v4.5 — Galaxy Compact Navigation
- Portrait home now shows only Turbo and Live Status; FPS, Boost, Graphics, Tools and Device are separate navigation sections.
- Reduced hero control size and card padding to avoid an excessively long home screen.
- Premium serif display typography for brand headings, refined spacing and Galaxy navy/indigo/violet gradients.
- Floating Hub uses a Galaxy notification banner with a short entrance animation.
- RAM and cache actions report separate completion messages in the Floating Hub. RAM action requests Android to stop eligible background processes; cache action only clears this app's own cache, not every installed app's cache.
- Floating panel remains draggable from its header and the bubble can be moved around the screen.


## Upgrade v4.7 — Auto Game Session + Android-safe controls
- Added AUTO START SESSION in the main app and floating hub: applies the selected display profile, runs the permitted local boost actions, then launches the saved game.
- Thermal Guard can cancel automatic session start at 40°C battery temperature or above.
- App Manager now explains Android 14+ process restrictions and avoids reporting a false successful stop.
- Boost results explicitly distinguish IMZYY's own cache from other apps' cache.
- Android 14+ prevents ordinary third-party apps from killing other packages; Android also provides no public API for silently clearing all other apps' caches. Samsung Game Booster's privileged functions cannot be remotely controlled by an unrelated app through a supported public API.
- Source-level update only; build and real-device validation are still required.


## Upgrade v4.8 — Voice Studio + Adaptive Thermal Guard
- Added an in-app offline Voice Studio: records microphone audio with explicit runtime permission, then plays pitch/ring-modulated Female, Male, Robot and Child-style presets.
- Voice effects are playback/processed-audio effects inside IMZYY. Android does not expose a supported public API for replacing the microphone stream sent by arbitrary games, phone calls, or third-party apps, so this does not claim system-wide live voice replacement.
- Added Voice Studio and App Permissions shortcuts to the main Tools section and floating panel. Permission grants remain user-controlled in Android Settings; the app cannot silently grant every system permission.
- Thermal Guard now warns from 42°C and blocks boost / auto-start at 44°C using the Android battery-temperature reading. This is a conservative load guard, not an active cooler; it cannot force-cool the chipset or guarantee a particular temperature while maintaining maximum performance. Android thermal status may throttle the device independently.
- Cache cleanup remains automatic for IMZYY's own cache only. Android does not provide ordinary apps a public API to silently clear all other apps' cache. Background-process stop requests are best-effort and restricted on Android 14+.
- Version bumped to 4.8 (versionCode 10). Source-level update; build and Samsung-device validation are still required.


## v5.0 — Cache Control Center
- Added installed-app inventory with search and per-app Manage shortcut to Android App Info / Storage settings.
- Added shortcut to system Storage settings.
- The assistant can enumerate installed packages using QUERY_ALL_PACKAGES (distribution through Google Play may require policy approval).
- Important Android limitation: ordinary third-party apps cannot silently clear every other app's cache on modern Android. The user must confirm cleanup in each app's system settings; no cache deletion is falsely reported as completed.
- Build/device validation has not been performed in this environment.


## v5.0 Cache Scanner
- Floating Window now includes CACHE SCAN with per-app cache estimates, sorted largest first, and search-free inventory display.
- Uses Android StorageStatsManager and requires the user to enable Usage Access in Android special app access settings.
- CLEAR opens the selected app's Android storage-management screen. The user confirms the action there.
- Android does not expose a public third-party API for silently clearing another app's cache from an overlay. Direct mass clearing requires privileged/system access and is intentionally not faked.
- Cache sizes are estimates returned by Android and may be unavailable for some packages or work profiles.


## v5.1 — Android System Cache Reclaimer (no Shizuku)
- Added a system-level cache cleanup entry point using `StorageManager.ACTION_CLEAR_APP_CACHE` on Android 11+. Android displays its own confirmation UI; IMZYY does not silently delete other apps' private data. The documented action targets eligible external cache directories; internal/protected cache may remain.
- Added the special All files access permission flow (`MANAGE_EXTERNAL_STORAGE`). The user must explicitly enable it in Android Settings before requesting system cleanup. Some firmware may restrict or omit the system dialog. This special access may also be restricted by app-store distribution policies; this project is intended for direct testing/sideloading.
- Cache inventory still uses Usage Access + `StorageStatsManager`; per-app row action is now labelled MANAGE because Android does not expose a public per-package cache-delete API to ordinary apps.
- Floating Window includes SYSTEM CLEAR ALL CACHE, which opens Cache Control Center for the same permission and confirmation flow.
- This route is independent of Shizuku/root. It requests system-managed cleanup of app external cache; Android decides what is eligible and reports whether the action completed. It is not a guarantee that every byte shown in cache estimates will be removed.
- `ACTION_CLEAR_APP_CACHE` may affect battery life and cause apps to rebuild temporary files. Use it when storage cleanup is actually needed, not repeatedly as a performance booster.
- Source-level update only. Gradle build and Samsung A07 device validation have not been performed in this environment.
