package com.imzyyknox.gameturbo;

import android.animation.ValueAnimator;
import android.app.*;
import android.app.usage.StorageStats;
import android.app.usage.StorageStatsManager;
import android.app.AppOpsManager;
import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.os.storage.StorageManager;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.io.File;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.io.IOException;

public class FloatingService extends Service {
    static boolean running;
    private static final int CY = 0xFF53E9FF, BL = 0xFF3C86FF, PU = 0xFF9270FF, OK = 0xFF55E7A9, WARN = 0xFFFFC857, BAD = 0xFFFF6B6B;
    private WindowManager wm;
    private SharedPreferences sp;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private TextView bubble, status, tRam, tBat, tTemp, tTherm, tHz;
    private final ArrayList<TextView> fpsBtns = new ArrayList<>();
    private static final int[] TARGETS = {10, 30, 60, 90, 0};
    private final FpsEngine.Meter meter = new FpsEngine.Meter();
    private View panel;
    private View fill;
    private int barW;
    private WindowManager.LayoutParams bp, pp;
    private final ArrayList<TextView> toggles = new ArrayList<>();
    private final Runnable tick = new Runnable() { public void run() { refresh(); ui.postDelayed(this, 2000); } };
    private final BroadcastReceiver orientationReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) { ui.postDelayed(FloatingService.this::reflowForOrientation, 120); }
    };

    @Override public void onCreate() {
        super.onCreate();
        running = true;
        sp = getSharedPreferences("turbo", MODE_PRIVATE);
        startForeground(7, notification());
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        IntentFilter cfg = new IntentFilter(Intent.ACTION_CONFIGURATION_CHANGED);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(orientationReceiver, cfg, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(orientationReceiver, cfg);
        showBubble();
    }

    private Notification notification() {
        String ch = "imzyy_turbo";
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(
                new NotificationChannel(ch, "Game Turbo Panel", NotificationManager.IMPORTANCE_LOW));
        PendingIntent stop = PendingIntent.getService(this, 1, new Intent(this, FloatingService.class).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, ch).setContentTitle("IMZYY KNOX Game Turbo")
                .setContentText("Floating hub aktif • tap bubble ⚡")
                .setSmallIcon(android.R.drawable.ic_menu_manage)
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "STOP", stop).build()).build();
    }

    // ---------- UI helpers ----------
    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + .5f); }
    private GradientDrawable bg(int c1, int c2, int r, int stroke) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{c1, c2});
        g.setCornerRadius(dp(r));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }
    private TextView txt(String s, int sz, int c, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sz); t.setTextColor(c);
        if (bold) t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        return t;
    }
    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        return r;
    }
    private LinearLayout.LayoutParams mt(int top) { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.topMargin = dp(top); return p; }
    private LinearLayout.LayoutParams w1(boolean first) { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1); if (!first) p.leftMargin = dp(6); return p; }
    private WindowManager.LayoutParams lp(int w, int h) {
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.START;
        return p;
    }
    private void status(String s, int c) {
        if (status != null) {
            status.setText("✦  " + s);
            status.setTextColor(c);
            status.setAlpha(.55f);
            status.setScaleX(.985f); status.setScaleY(.985f);
            status.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(220).start();
            status.setBackground(bg(c == OK ? 0xFF123B42 : c == WARN ? 0xFF40351F : 0xFF18284A,
                    0xFF10182D, 12, c == OK ? 0x6655E7A9 : c == WARN ? 0x66FFC857 : 0x665C8DFF));
        }
    }
    private void open(Intent i) {
        try { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); }
        catch (Exception e) { status("Tidak tersedia di perangkat ini", WARN); }
    }

    private TextView tile(LinearLayout r, String label, boolean first) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL); c.setGravity(Gravity.CENTER); c.setPadding(0, dp(8), 0, dp(8));
        c.setBackground(bg(0xFF0D1723, 0xFF08121C, 12, 0x2253E9FF));
        TextView l = txt(label, 8, 0xFF8394A9, false); l.setLetterSpacing(.12f);
        TextView v = txt("--", 15, 0xFFFFFFFF, true);
        c.addView(l); c.addView(v);
        r.addView(c, w1(first));
        return v;
    }
    private void btn(LinearLayout r, String s, boolean first, Runnable a) {
        TextView t = txt(s, 10, 0xFFBFF8FF, true);
        t.setGravity(Gravity.CENTER); t.setPadding(dp(4), dp(11), dp(4), dp(11));
        t.setBackground(bg(0xFF12344B, 0xFF102140, 12, 0x4453E9FF));
        t.setOnClickListener(v -> a.run());
        r.addView(t, w1(first));
    }
    private void toggle(LinearLayout r, String key, String label, boolean first) {
        TextView t = txt(label, 10, 0xFFA4B7CA, true);
        t.setGravity(Gravity.CENTER); t.setPadding(dp(4), dp(11), dp(4), dp(11));
        t.setTag(new String[]{key, label});
        t.setOnClickListener(v -> {
            boolean n = !sp.getBoolean(key, false);
            if (key.equals("dnd")) dnd(n); else if (key.equals("bright")) bright(n); else awake(n);
            paintAll();
        });
        toggles.add(t); paint(t);
        r.addView(t, w1(first));
    }
    private void paint(TextView t) {
        String[] k = (String[]) t.getTag();
        boolean on = sp.getBoolean(k[0], false);
        t.setText((on ? "● " : "○ ") + k[1]);
        t.setTextColor(on ? 0xFF03131C : 0xFFA4B7CA);
        t.setBackground(on ? bg(CY, BL, 12, 0) : bg(0xFF0D1723, 0xFF08121C, 12, 0x33FFFFFF));
    }
    private void paintAll() { for (TextView t : toggles) paint(t); }

    private void section(LinearLayout parent, String name) {
        TextView t = txt(name, 8, 0xFF8394A9, true); t.setLetterSpacing(.15f);
        parent.addView(t, mt(13));
    }
    private void smartToggle(LinearLayout parent, String key, String title, String detail) {
        LinearLayout item = new LinearLayout(this); item.setGravity(Gravity.CENTER_VERTICAL);
        item.setPadding(dp(9), dp(7), dp(7), dp(7));
        item.setBackground(bg(0xFF0B1521, 0xFF0A1019, 12, 0x223FBCD4));
        LinearLayout textCol = new LinearLayout(this); textCol.setOrientation(LinearLayout.VERTICAL);
        TextView name = txt(title, 9, 0xFFEAF5FF, true);
        TextView desc = txt(detail, 7, 0xFF8394A9, false);
        textCol.addView(name); textCol.addView(desc);
        Switch sw = new Switch(this); sw.setChecked(sp.getBoolean(key, false));
        sw.setOnCheckedChangeListener((b, on) -> {
            if ("frame_opt".equals(key)) { sp.edit().putBoolean(key, on).apply(); if (on) setFps(0); else { FpsEngine.reset(this); status("Frame optimization off • system auto", WARN); } }
            else if ("battery_profile".equals(key)) {
                if (!ProfileEngine.batteryBalance(this, on)) { sw.setOnCheckedChangeListener(null); sw.setChecked(!on); sw.setOnCheckedChangeListener((bb, retry) -> { if (ProfileEngine.batteryBalance(this, retry)) { sp.edit().putBoolean(key, retry).apply(); status(retry ? "Battery Balance aktif" : "Battery Balance off", OK); } else { sw.setOnCheckedChangeListener(null); sw.setChecked(!retry); sw.setOnCheckedChangeListener((b2, again) -> { if (ProfileEngine.batteryBalance(this, again)) sp.edit().putBoolean(key, again).apply(); }); open(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + getPackageName()))); status("Izinkan Ubah setelan sistem, lalu coba lagi", WARN); } }); open(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + getPackageName()))); status("Izinkan Ubah setelan sistem, lalu aktifkan lagi", WARN); }
                else { sp.edit().putBoolean(key, on).apply(); status(on ? "Battery Balance aktif • brightness + refresh rate diturunkan" : "Battery Balance off • brightness dipulihkan", OK); }
            } else if ("touch_profile".equals(key)) { sp.edit().putBoolean(key, on).apply(); open(new Intent(Settings.ACTION_DISPLAY_SETTINGS)); status("Atur Touch sensitivity jika tersedia di menu layar", WARN); }
            else sp.edit().putBoolean(key, on).apply();
        });
        item.addView(textCol, new LinearLayout.LayoutParams(0, -2, 1)); item.addView(sw);
        parent.addView(item, mt(6));
    }

    // ---------- Bubble ----------
    private void showBubble() {
        int s = dp(54);
        bubble = txt("⚡", 24, 0xFFFFFFFF, false);
        bubble.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{CY, BL, PU});
        g.setShape(GradientDrawable.OVAL); g.setStroke(dp(2), 0x88FFFFFF);
        bubble.setBackground(g);
        bp = lp(s, s); bp.x = dp(4); bp.y = dp(220);
        int f0 = sp.getInt("fps", -1);
        if (f0 >= 0) FpsEngine.prefer(bp, this, FpsEngine.pick(this, f0));
        applyAwake();
        bubble.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy; float tx, ty; boolean moved;
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN: sx = bp.x; sy = bp.y; tx = e.getRawX(); ty = e.getRawY(); moved = false; bubble.setAlpha(1f); return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - tx, dy = e.getRawY() - ty;
                        if (Math.abs(dx) + Math.abs(dy) > dp(6)) moved = true;
                        if (moved) { bp.x = sx + (int) dx; bp.y = sy + (int) dy; try { wm.updateViewLayout(bubble, bp); } catch (Exception x) { } }
                        return true;
                    case MotionEvent.ACTION_UP: if (!moved) openPanel(); else snap(); return true;
                }
                return false;
            }
        });
        wm.addView(bubble, bp);
    }
    private void snap() {
        int w = getResources().getDisplayMetrics().widthPixels, size = dp(54);
        int to = (bp.x + size / 2 < w / 2) ? dp(4) : w - size - dp(4);
        int h = getResources().getDisplayMetrics().heightPixels;
        bp.y = Math.max(dp(8), Math.min(bp.y, h - size - dp(8)));
        try { wm.updateViewLayout(bubble, bp); } catch (Exception ignored) { }
        ValueAnimator a = ValueAnimator.ofInt(bp.x, to);
        a.setDuration(220);
        a.addUpdateListener(v -> { bp.x = (Integer) v.getAnimatedValue(); try { wm.updateViewLayout(bubble, bp); } catch (Exception x) { } });
        a.start();
        bubble.setAlpha(.8f);
    }

    // ---------- Panel ----------
    private void openPanel() {
        if (panel != null) return;
        bubble.setVisibility(View.GONE);
        int sw = getResources().getDisplayMetrics().widthPixels;
        int pw = Math.min(dp(340), sw - dp(20));
        barW = pw - dp(28);
        toggles.clear(); fpsBtns.clear();

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(12), dp(14), dp(14));
        box.setBackground(bg(0xF21A2450, 0xF2060B18, 24, 0x665C8DFF));

        LinearLayout head = row();
        TextView logo = txt("ϟ", 20, CY, true); logo.setPadding(0, 0, dp(10), 0);
        LinearLayout titles = new LinearLayout(this); titles.setOrientation(LinearLayout.VERTICAL);
        TextView t1 = txt("IMZYY KNOX", 15, 0xFFFFFFFF, true); t1.setTypeface(Typeface.create("serif", Typeface.BOLD)); t1.setLetterSpacing(.1f);
        TextView t2 = txt("GALAXY CONTROL • DRAG TO MOVE • v5.0", 7, 0xFF9CAED0, false); t2.setLetterSpacing(.10f);
        titles.addView(t1); titles.addView(t2);
        head.addView(logo); head.addView(titles, new LinearLayout.LayoutParams(0, -2, 1));
        TextView min = txt("—", 14, 0xFFBFF8FF, true); min.setPadding(dp(12), dp(4), dp(12), dp(4)); min.setOnClickListener(v -> closePanel());
        TextView x = txt("✕", 14, BAD, true); x.setPadding(dp(8), dp(4), dp(4), dp(4)); x.setOnClickListener(v -> stopSelf());
        head.addView(min); head.addView(x);
        head.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy; float tx, ty;
            public boolean onTouch(View v, MotionEvent e) {
                if (pp == null) return false;
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN: sx = pp.x; sy = pp.y; tx = e.getRawX(); ty = e.getRawY(); return true;
                    case MotionEvent.ACTION_MOVE:
                        int sw = getResources().getDisplayMetrics().widthPixels;
                        int sh = getResources().getDisplayMetrics().heightPixels;
                        pp.x = Math.max(0, Math.min(sw - pp.width, sx + (int) (e.getRawX() - tx)));
                        pp.y = Math.max(0, Math.min(sh - pp.height, sy + (int) (e.getRawY() - ty)));
                        try { wm.updateViewLayout(panel, pp); } catch (Exception ex) { }
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL: return true;
                }
                return false;
            }
        });
        box.addView(head);

        LinearLayout stats = row();
        tRam = tile(stats, "RAM USED", true); tBat = tile(stats, "BATTERY", false);
        tTemp = tile(stats, "TEMP", false); tTherm = tile(stats, "THERMAL", false);
        box.addView(stats, mt(10));

        FrameLayout track = new FrameLayout(this);
        track.setBackground(bg(0xFF172635, 0xFF172635, 3, 0));
        fill = new View(this); fill.setBackground(bg(CY, PU, 3, 0));
        track.addView(fill, new FrameLayout.LayoutParams(1, dp(6)));
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(-1, dp(6));
        tlp.topMargin = dp(8);
        box.addView(track, tlp);

        status = txt("✦  SIAP • TAP TURBO BOOST", 9, 0xFFBFEAFF, true);
        status.setPadding(dp(11), dp(10), dp(11), dp(10));
        status.setBackground(bg(0xFF18284A, 0xFF10182D, 12, 0x665C8DFF));
        box.addView(status, mt(8));

        TextView turbo = txt("⚡  TURBO BOOST", 14, 0xFF03131C, true);
        turbo.setGravity(Gravity.CENTER); turbo.setLetterSpacing(.1f); turbo.setPadding(0, dp(13), 0, dp(13));
        turbo.setBackground(bg(CY, PU, 16, 0));
        turbo.setOnClickListener(v -> boost(0));
        box.addView(turbo, mt(10));

        LinearLayout tg = row();
        toggle(tg, "dnd", "DND", true); toggle(tg, "awake", "AWAKE", false); toggle(tg, "bright", "MAX BRIGHT", false);
        box.addView(tg, mt(10));

        LinearLayout fh = row();
        TextView fl = txt("FPS TARGET", 8, 0xFF8394A9, true); fl.setLetterSpacing(.15f);
        tHz = txt("-- Hz", 12, CY, true);
        fh.addView(fl, new LinearLayout.LayoutParams(0, -2, 1)); fh.addView(tHz);
        box.addView(fh, mt(12));
        LinearLayout fr = row();
        for (int i = 0; i < TARGETS.length; i++) {
            final int tgt = TARGETS[i];
            TextView t = txt(tgt == 0 ? "MAX" : String.valueOf(tgt), 11, 0xFFBFF8FF, true);
            t.setGravity(Gravity.CENTER); t.setPadding(0, dp(10), 0, dp(10));
            t.setOnClickListener(v -> setFps(tgt));
            fpsBtns.add(t); fr.addView(t, w1(i == 0));
        }
        box.addView(fr, mt(6));
        TextView sliderCaption = txt("PRECISION FPS • GESER UNTUK MEMILIH", 8, 0xFF8394A9, true);
        sliderCaption.setLetterSpacing(.12f);
        box.addView(sliderCaption, mt(12));
        TextView sliderReadout = txt("90 Hz", 18, CY, true);
        box.addView(sliderReadout, mt(3));
        SeekBar fpsSlider = new SeekBar(this);
        fpsSlider.setMax(110); fpsSlider.setProgress(80);
        fpsSlider.setProgressTintList(android.content.res.ColorStateList.valueOf(CY));
        fpsSlider.setThumbTintList(android.content.res.ColorStateList.valueOf(PU));
        fpsSlider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean user) {
                int requested = 10 + p, actual = FpsEngine.pick(FloatingService.this, requested);
                sliderReadout.setText(actual + " Hz" + (actual != requested ? " • nearest supported" : ""));
            }
            public void onStartTrackingTouch(SeekBar b) {}
            public void onStopTrackingTouch(SeekBar b) { int v = 10 + b.getProgress(); setFps(v >= 115 ? 0 : v); }
        });
        box.addView(fpsSlider, mt(2));
        paintFps();

        section(box, "RENDER & DISPLAY PROFILES");
        box.addView(txt("Pilih profil layar dan tekan APPLY. Ini mengubah refresh rate yang didukung, bukan renderer Vulkan/OpenGL atau grafis internal game.", 9, 0xFF8394A9, false), mt(5));
        Spinner renderer = new Spinner(this);
        renderer.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"SYSTEM AUTO", "COMPATIBILITY • LOW RATE", "BALANCED • 60 Hz", "PERFORMANCE • MAX RATE"}));
        renderer.setSelection(sp.getInt("render_profile", 0));
        renderer.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            public void onNothingSelected(android.widget.AdapterView<?> p) {}
            public void onItemSelected(android.widget.AdapterView<?> p, View v, int pos, long id) { sp.edit().putInt("render_profile", pos).apply(); }
        });
        box.addView(renderer, mt(4));
        btn(box, "APPLY DISPLAY PROFILE", true, this::applyRenderProfile);
        section(box, "GRAPHICS EXPERIENCE");
        box.addView(txt("Preset rekomendasi grafis. Detail tekstur, shader, resolusi internal dan renderer tetap diatur oleh game.", 9, 0xFF8394A9, false), mt(5));
        Spinner graphics = new Spinner(this);
        graphics.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"SMART AUTO", "ULTRA CLARITY", "BALANCED", "PERFORMANCE", "THERMAL SAFE"}));
        graphics.setSelection(sp.getInt("graphics_profile", 0));
        graphics.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            public void onNothingSelected(android.widget.AdapterView<?> p) {}
            public void onItemSelected(android.widget.AdapterView<?> p, View v, int pos, long id) { sp.edit().putInt("graphics_profile", pos).apply(); }
        });
        box.addView(graphics, mt(4));
        btn(box, "APPLY GRAPHIC PROFILE", true, () -> {
            int mode = sp.getInt("graphics_profile", 0); String result = ProfileEngine.applyGraphics(this, mode);
            if (result.startsWith("Izin")) open(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + getPackageName())));
            status(result, result.startsWith("Refresh") ? OK : WARN);
        });
        smartToggle(box, "frame_opt", "FRAME RATE OPTIMIZATION", "Gunakan refresh rate layar yang didukung dan pantau kestabilannya.");
        smartToggle(box, "thermal_guard", "THERMAL GUARD", "Waspada 42°C • tahan boost 44°C (suhu baterai); bukan pendingin aktif.");
        smartToggle(box, "battery_profile", "BATTERY BALANCE", "Simpan preferensi hemat daya untuk sesi bermain.");
        smartToggle(box, "touch_profile", "TOUCH RESPONSE", "Preferensi sentuhan; tidak mengubah sampling rate hardware.");
        LinearLayout gameRow = row();
        btn(gameRow, "CHOOSE GAME", true, this::chooseGame);
        btn(gameRow, "AUTO START", false, this::startGameSession);
        box.addView(gameRow, mt(6));
        box.addView(txt("AUTO START: terapkan profil layar + boost yang diizinkan, lalu buka game pilihan. Cache yang dibersihkan hanya cache IMZYY.", 8, 0xFF8394A9, false), mt(4));

        LinearLayout a1 = row();
        btn(a1, "CLEAN RAM", true, () -> boost(1)); btn(a1, "CLEAR CACHE", false, () -> boost(2)); btn(a1, "PING", false, this::ping);
        box.addView(a1, mt(8));
        LinearLayout a2 = row();
        btn(a2, "DISPLAY", true, () -> open(new Intent(Settings.ACTION_DISPLAY_SETTINGS)));
        btn(a2, "BATTERY", false, () -> open(new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)));
        btn(a2, "OPEN HUB", false, () -> open(new Intent(this, MainActivity.class)));
        box.addView(a2, mt(8));
        LinearLayout voiceRow = row();
        btn(voiceRow, "VOICE STUDIO", true, () -> open(new Intent(this, VoiceStudioActivity.class)));
        btn(voiceRow, "APP SETTINGS", false, () -> open(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()))));
        box.addView(voiceRow, mt(8));
        LinearLayout appTools = row();
        btn(appTools, "APP MANAGER", true, this::openAppManager);
        btn(appTools, "CACHE SCAN", false, this::showCacheScanner);
        box.addView(appTools, mt(8));

        TextView foot = txt("IMZYY KNOX • PERFORMANCE SUITE v5.0", 8, 0xFF52667A, false);
        foot.setGravity(Gravity.CENTER); foot.setLetterSpacing(.1f);
        box.addView(foot, mt(10));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setBackground(bg(0xF21A2450, 0xF2060B18, 24, 0x665C8DFF));
        scroll.addView(box, new ScrollView.LayoutParams(-1, -2));
        panel = scroll;
        pp = lp(pw, Math.min((int)(getResources().getDisplayMetrics().heightPixels * .64f), dp(560)));
        pp.x = (sw - pw) / 2; pp.y = dp(60);
        applyAwake();
        scroll.setAlpha(0f); scroll.setScaleX(.96f); scroll.setScaleY(.96f);
        wm.addView(panel, pp);
        scroll.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(220).start();
        meter.start(tHz);
        ui.post(tick);
    }
    private void closePanel() {
        ui.removeCallbacks(tick); meter.stop();
        if (panel != null) { try { wm.removeView(panel); } catch (Exception e) { } panel = null; pp = null; }
        if (bubble != null) bubble.setVisibility(View.VISIBLE);
    }

    // ---------- Cache scanner (usage-access statistics + Android-confirmed cleanup) ----------
    private static class CacheRow {
        String label, pkg; long bytes;
        CacheRow(String l, String p, long b) { label=l; pkg=p; bytes=b; }
    }
    private boolean hasUsageAccess() {
        try {
            AppOpsManager ops = (AppOpsManager) getSystemService(APP_OPS_SERVICE);
            int mode = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), getPackageName());
            return mode == AppOpsManager.MODE_ALLOWED;
        } catch (Exception e) { return false; }
    }
    private String cacheSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024L*1024) return String.format(java.util.Locale.US, "%.1f KB", bytes/1024d);
        if (bytes < 1024L*1024*1024) return String.format(java.util.Locale.US, "%.1f MB", bytes/(1024d*1024));
        return String.format(java.util.Locale.US, "%.2f GB", bytes/(1024d*1024*1024));
    }
    private void showCacheScanner() {
        LinearLayout content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(12),dp(8),dp(12),dp(8));
        TextView explanation = txt("CACHE INVENTORY • ukuran cache per aplikasi. SYSTEM CLEAR ALL meminta Android membersihkan cache eksternal yang eligible, setelah izin Akses semua file dan konfirmasi sistem. Tombol MANAGE membuka halaman aplikasi.",9,0xFF9DB0C6,false);
        content.addView(explanation, mt(3));
        TextView summary = txt("Menyiapkan pemindaian...",11,CY,true); content.addView(summary, mt(8));
        LinearLayout actions = row();
        TextView scan = txt("RESCAN",10,CY,true); scan.setGravity(Gravity.CENTER); scan.setPadding(dp(12),dp(10),dp(12),dp(10)); scan.setBackground(bg(0xFF183B50,0xFF12283B,10,0));
        TextView access = txt("USAGE ACCESS",10,0xFFFFFFFF,true); access.setGravity(Gravity.CENTER); access.setPadding(dp(12),dp(10),dp(12),dp(10)); access.setBackground(bg(0xFF29345A,0xFF1C2545,10,0));
        actions.addView(scan,new LinearLayout.LayoutParams(0,-2,1)); LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(0,-2,1); ap.leftMargin=dp(6); actions.addView(access,ap); content.addView(actions,mt(8));
        TextView systemClear=txt("SYSTEM CLEAR ALL CACHE",10,0xFFFFFFFF,true); systemClear.setGravity(Gravity.CENTER); systemClear.setPadding(dp(12),dp(11),dp(12),dp(11)); systemClear.setBackground(bg(0xFF174A5A,0xFF102D45,10,0)); systemClear.setOnClickListener(v->{try{Intent i=new Intent(this,CacheControlActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);}catch(Exception e){status("Cache Control Center tidak dapat dibuka",WARN);}}); content.addView(systemClear,mt(7));
        EditText filter = new EditText(this); filter.setSingleLine(true); filter.setTextColor(0xFFFFFFFF); filter.setHintTextColor(0xFF8394A9); filter.setHint("Cari aplikasi yang punya cache..."); content.addView(filter,mt(7));
        LinearLayout rows = new LinearLayout(this); rows.setOrientation(LinearLayout.VERTICAL);
        ArrayList<CacheRow> scannedRows = new ArrayList<>();
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(false); scroll.addView(rows); content.addView(scroll,new LinearLayout.LayoutParams(-1,dp(320)));
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("IMZYY CACHE SCANNER").setView(content).setNegativeButton("CLOSE",null).create();
        Runnable startScan = () -> {
            rows.removeAllViews();
            if (!hasUsageAccess()) {
                summary.setText("Usage Access belum diizinkan. Aktifkan agar ukuran cache bisa dibaca.");
                TextView hint=txt("Belum ada data cache yang dapat ditampilkan.",10,0xFF8394A9,false); hint.setPadding(0,dp(12),0,dp(12)); rows.addView(hint);
                return;
            }
            summary.setText("Memindai cache aplikasi...");
            new Thread(() -> {
                ArrayList<CacheRow> result = new ArrayList<>(); long total=0; int failed=0;
                PackageManager pm=getPackageManager(); StorageStatsManager sm=(StorageStatsManager)getSystemService(STORAGE_STATS_SERVICE);
                List<ApplicationInfo> installed=pm.getInstalledApplications(PackageManager.GET_META_DATA);
                for (ApplicationInfo info: installed) {
                    if (info.packageName.equals(getPackageName())) continue;
                    try { StorageStats st=sm.queryStatsForPackage(StorageManager.UUID_DEFAULT,info.packageName,android.os.Process.myUserHandle()); long b=st.getCacheBytes(); result.add(new CacheRow(String.valueOf(info.loadLabel(pm)),info.packageName,b)); total+=b; }
                    catch (Exception ex) { failed++; }
                }
                Collections.sort(result,(a,b)->Long.compare(b.bytes,a.bytes)); final long totalBytes=total; final int failedCount=failed;
                ui.post(() -> {
                    if (!dialog.isShowing()) return;
                    summary.setText(result.size()+" aplikasi dipindai • total cache terukur: "+cacheSize(totalBytes)+(failedCount>0?" • "+failedCount+" tidak terbaca":""));
                    scannedRows.clear(); scannedRows.addAll(result);
                    renderCacheInventory(rows, scannedRows, filter.getText().toString());
                });
            }).start();
        };
        scan.setOnClickListener(v -> startScan.run());
        filter.addTextChangedListener(new android.text.TextWatcher(){ public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int before,int count){renderCacheInventory(rows,scannedRows,s.toString());} public void afterTextChanged(android.text.Editable e){} });
        access.setOnClickListener(v -> { try { Intent i=new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); } catch(Exception e) { status("Halaman Usage Access tidak tersedia",WARN); } });
        dialog.setOnShowListener(v -> startScan.run());
        if (dialog.getWindow()!=null && Build.VERSION.SDK_INT>=26) dialog.getWindow().setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY);
        dialog.show();
    }
    private void renderCacheInventory(LinearLayout rows, List<CacheRow> data, String query) {
        rows.removeAllViews(); int shown=0; String q=query==null?"":query.toLowerCase(java.util.Locale.ROOT);
        for (CacheRow r:data) {
            if (r.bytes<=0 || (!r.label.toLowerCase(java.util.Locale.ROOT).contains(q) && !r.pkg.toLowerCase(java.util.Locale.ROOT).contains(q))) continue;
            LinearLayout item=row(); item.setPadding(dp(8),dp(8),dp(6),dp(8)); item.setBackground(bg(0xFF14233D,0xFF10182D,10,0x334F80C8));
            LinearLayout labels=new LinearLayout(this); labels.setOrientation(LinearLayout.VERTICAL);
            labels.addView(txt(r.label,10,0xFFFFFFFF,true)); labels.addView(txt(r.pkg+" • "+cacheSize(r.bytes),8,0xFF9DB0C6,false));
            item.addView(labels,new LinearLayout.LayoutParams(0,-2,1));
            TextView clear=txt("MANAGE",9,CY,true); clear.setGravity(Gravity.CENTER); clear.setPadding(dp(9),dp(9),dp(9),dp(9)); clear.setBackground(bg(0xFF183B50,0xFF12283B,9,0));
            clear.setOnClickListener(v -> openAppStorage(r.pkg)); item.addView(clear);
            LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,-2); ip.topMargin=dp(5); rows.addView(item,ip); shown++;
        }
        if(shown==0) rows.addView(txt(q.isEmpty()?"Tidak ditemukan cache terukur.":"Tidak ada aplikasi cache yang cocok.",10,0xFF8394A9,false));
    }
    private void openAppStorage(String pkg) {
        try {
            Intent i;
            if (Build.VERSION.SDK_INT >= 31) i=new Intent("android.settings.MANAGE_APP_STORAGE",Uri.parse("package:"+pkg));
            else i=new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+pkg));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i);
        } catch(Exception e) {
            try { startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+pkg)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }
            catch(Exception ex) { status("Halaman penyimpanan aplikasi tidak tersedia",WARN); }
        }
    }

    // ---------- App manager (Android permission-safe) ----------
    private void openAppManager() {
        PackageManager pm = getPackageManager();
        ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        ArrayList<ResolveInfo> apps = new ArrayList<>(pm.queryIntentActivities(
            new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0));
        java.util.Collections.sort(apps, (a, b) -> String.CASE_INSENSITIVE_ORDER.compare(
            String.valueOf(a.loadLabel(pm)), String.valueOf(b.loadLabel(pm))));
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(12), dp(8), dp(12), dp(8));
        TextView info = txt(Build.VERSION.SDK_INT >= 34
            ? "Android 14+ membatasi aplikasi pihak ketiga menghentikan proses aplikasi lain. STOP tidak bisa memaksa berhenti. CACHE SCAN menampilkan ukuran cache; MANAGE membuka halaman aplikasi. SYSTEM CLEAR ALL memakai dialog pembersihan cache resmi Android setelah izin khusus disetujui."
            : "STOP mengirim permintaan penghentian proses latar (bukan Force Stop). CACHE membuka Info Aplikasi; pembersihan cache massal hanya tersedia melalui dialog sistem dan izin khusus Android.", 10, 0xFF8394A9, false);
        list.addView(info, mt(4));
        for (ResolveInfo r : apps) {
            String pkg = r.activityInfo.packageName;
            if (pkg.equals(getPackageName())) continue;
            LinearLayout item = new LinearLayout(this);
            item.setGravity(Gravity.CENTER_VERTICAL);
            item.setPadding(dp(8), dp(8), dp(8), dp(8));
            item.setBackground(bg(0xFF14233D, 0xFF10182D, 12, 0x334F80C8));
            LinearLayout labels = new LinearLayout(this);
            labels.setOrientation(LinearLayout.VERTICAL);
            TextView name = txt(String.valueOf(r.loadLabel(pm)), 11, 0xFFFFFFFF, true);
            TextView packageName = txt(pkg, 8, 0xFF8394A9, false);
            labels.addView(name); labels.addView(packageName);
            item.addView(labels, new LinearLayout.LayoutParams(0, -2, 1));
            TextView stop = txt("STOP", 9, CY, true);
            stop.setGravity(Gravity.CENTER); stop.setPadding(dp(8), dp(9), dp(8), dp(9));
            stop.setBackground(bg(0xFF183B50, 0xFF12283B, 9, 0));
            stop.setOnClickListener(v -> {
                if (Build.VERSION.SDK_INT >= 34) {
                    status("Android 14+ memblokir penghentian paksa aplikasi lain", WARN);
                    return;
                }
                try {
                    am.killBackgroundProcesses(pkg);
                    status("Permintaan proses latar dikirim: " + r.loadLabel(pm), OK);
                } catch (Exception ex) { status("Android menolak permintaan untuk aplikasi ini", WARN); }
            });
            TextView manage = txt("CACHE", 9, 0xFFFFFFFF, true);
            manage.setGravity(Gravity.CENTER); manage.setPadding(dp(8), dp(9), dp(8), dp(9));
            manage.setBackground(bg(0xFF29345A, 0xFF1C2545, 9, 0));
            manage.setOnClickListener(v -> {
                try {
                    openAppStorage(pkg);
                } catch (Exception ex) { status("Halaman info aplikasi tidak tersedia", WARN); }
            });
            item.addView(stop, new LinearLayout.LayoutParams(-2, -2));
            LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-2, -2); mp.leftMargin = dp(5);
            item.addView(manage, mp);
            LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, -2); ip.topMargin = dp(5);
            list.addView(item, ip);
        }
        ScrollView sc = new ScrollView(this); sc.addView(list);
        new AlertDialog.Builder(this).setTitle("IMZYY APP MANAGER")
            .setView(sc).setPositiveButton("OPEN STORAGE", (dialog, which) -> {
                try { startActivity(new Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }
                catch (Exception ex) { open(new Intent(Settings.ACTION_SETTINGS)); }
            }).setNegativeButton("CLOSE", null).show();
    }
    private int stopApiLevel() { return 26; }

    // ---------- Live stats ----------
    private ActivityManager.MemoryInfo mem() {
        ActivityManager.MemoryInfo m = new ActivityManager.MemoryInfo();
        ((ActivityManager) getSystemService(ACTIVITY_SERVICE)).getMemoryInfo(m);
        return m;
    }
    private void refresh() {
        if (panel == null) return;
        ActivityManager.MemoryInfo mi = mem();
        int used = (int) (100 - mi.availMem * 100 / Math.max(1, mi.totalMem));
        tRam.setText(used + "%"); tRam.setTextColor(used > 85 ? BAD : used > 70 ? WARN : OK);
        ViewGroup.LayoutParams f = fill.getLayoutParams(); f.width = Math.max(1, barW * used / 100); fill.setLayoutParams(f);
        Intent b = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (b != null) {
            int lv = b.getIntExtra("level", 0) * 100 / Math.max(1, b.getIntExtra("scale", 100));
            float t = b.getIntExtra("temperature", 0) / 10f;
            tBat.setText(lv + "%"); tTemp.setText(t + "°"); tTemp.setTextColor(t >= 42 ? BAD : t >= 38 ? WARN : OK);
        }
        if (Build.VERSION.SDK_INT >= 29) {
            int ts = ((PowerManager) getSystemService(POWER_SERVICE)).getCurrentThermalStatus();
            tTherm.setText(ts <= 0 ? "COOL" : ts == 1 ? "WARM" : ts == 2 ? "WARM+" : ts == 3 ? "HOT" : "CRIT");
            tTherm.setTextColor(ts <= 0 ? OK : ts <= 2 ? WARN : BAD);
        } else tTherm.setText("N/A");
    }

    // ---------- Boost features (real, non-root) ----------
    private int killBg() {
        if (Build.VERSION.SDK_INT >= 34) return 0;
        PackageManager pm = getPackageManager();
        ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        int n = 0;
        for (ResolveInfo r : pm.queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)) {
            String p = r.activityInfo.packageName;
            if (p.equals(getPackageName()) || (r.activityInfo.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0) continue;
            am.killBackgroundProcesses(p); n++;
        }
        return n;
    }
    private void boost(final int mode) { // 0 = turbo, 1 = RAM only, 2 = cache only
        if (sp.getBoolean("thermal_guard", false)) { Intent battery = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED)); float temp = battery == null ? 0 : battery.getIntExtra("temperature", 0) / 10f; if (temp >= 44f) { status("THERMAL GUARD: boost dihentikan • suhu " + temp + "°C", WARN); return; }
            if (temp >= 42f) status("THERMAL GUARD: suhu tinggi " + temp + "°C • mode hati-hati", WARN); }
        status("⚡ Boosting…", WARN);
        new Thread(() -> {
            long before = mem().availMem;
            int n = mode < 2 ? killBg() : 0;
            long kb = 0;
            if (mode != 1) { kb = size(getCacheDir()) >> 10; delete(getCacheDir()); }
            try { Thread.sleep(900); } catch (Exception e) { }
            final long mb = Math.max(0, (mem().availMem - before) >> 20);
            final int fn = n; final long fk = kb;
            ui.post(() -> {
                if (mode == 0) {
                    awake(true);
                    NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                    if (nm.isNotificationPolicyAccessGranted() && !sp.getBoolean("dnd", false)) dnd(true);
                    paintAll();
                }
                String processNote = Build.VERSION.SDK_INT >= 34
                        ? "Android 14+: proses aplikasi lain dibatasi"
                        : fn + " permintaan proses latar";
                String message;
                if (mode == 1) message = "RAM ACTION • " + processNote + " • ~" + mb + " MB tersedia";
                else if (mode == 2) message = "CACHE CLEAN COMPLETE • " + fk + " KB cache IMZYY dibersihkan";
                else message = "TURBO COMPLETE • " + processNote + " • ~" + mb + " MB • " + fk + " KB cache IMZYY";
                status(message, OK);
                refresh();
            });
        }).start();
    }
    private void ping() {
        status("📡 Mengetes latency…", WARN);
        new Thread(() -> {
            long best = 9999, tot = 0; int ok = 0;
            for (int i = 0; i < 3; i++) {
                try {
                    long t = SystemClock.elapsedRealtime();
                    HttpURLConnection c = (HttpURLConnection) new URL("https://www.google.com/generate_204").openConnection();
                    c.setConnectTimeout(3000); c.setReadTimeout(3000); c.getResponseCode(); c.disconnect();
                    long d = SystemClock.elapsedRealtime() - t;
                    best = Math.min(best, d); tot += d; ok++;
                } catch (Exception e) { }
            }
            final String m = ok == 0 ? "✕ Tidak ada internet" : "📡 Ping rata-rata " + (tot / ok) + " ms • terbaik " + best + " ms";
            final int col = ok == 0 ? BAD : OK;
            ui.post(() -> status(m, col));
        }).start();
    }
    private void dnd(boolean on) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (!nm.isNotificationPolicyAccessGranted()) {
            sp.edit().putBoolean("dnd", false).apply();
            open(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS));
            status("Izinkan akses DND, lalu tap lagi", WARN); return;
        }
        if (on) {
            sp.edit().putInt("prevf", nm.getCurrentInterruptionFilter()).putBoolean("dnd", true).apply();
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALARMS);
            status("DND aktif (alarm tetap bunyi)", OK);
        } else {
            nm.setInterruptionFilter(sp.getInt("prevf", NotificationManager.INTERRUPTION_FILTER_ALL));
            sp.edit().putBoolean("dnd", false).apply();
            status("DND dikembalikan", 0xFF8394A9);
        }
    }
    private void bright(boolean on) {
        if (!Settings.System.canWrite(this)) {
            sp.edit().putBoolean("bright", false).apply();
            if (!sp.getBoolean("write_settings_prompted", false)) {
                sp.edit().putBoolean("write_settings_prompted", true).apply();
                open(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + getPackageName())));
            } else status("Izin belum aktif. Aktifkan sekali dari Pengaturan aplikasi.", WARN);
            return;
        }
        ContentResolver cr = getContentResolver();
        try {
            if (on) {
                sp.edit().putInt("pb", Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, 128))
                        .putInt("pm", Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, 0)).putBoolean("bright", true).apply();
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, 0);
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, 255);
                status("Brightness maksimal", OK);
            } else {
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, sp.getInt("pb", 128));
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, sp.getInt("pm", 0));
                sp.edit().putBoolean("bright", false).apply();
                status("Brightness dikembalikan", 0xFF8394A9);
            }
        } catch (Exception e) { status("Gagal ubah brightness", BAD); }
    }
    private void paintFps() {
        int sel = sp.getInt("fps", -1);
        for (int i = 0; i < fpsBtns.size(); i++) {
            TextView t = fpsBtns.get(i); boolean on = TARGETS[i] == sel;
            t.setTextColor(on ? 0xFF03131C : 0xFFBFF8FF);
            t.setBackground(on ? bg(CY, PU, 12, 0) : bg(0xFF12344B, 0xFF102140, 12, 0x4453E9FF));
        }
    }
    private void applyRenderProfile() {
        int profile = sp.getInt("render_profile", 0);
        if (profile == 0) {
            FpsEngine.reset(this);
            status("SYSTEM AUTO: refresh rate dikembalikan", OK);
            return;
        }
        java.util.List<Integer> rates = FpsEngine.rates(this);
        if (rates.isEmpty()) { status("Mode refresh rate tidak terbaca", WARN); return; }
        int target = profile == 1 ? rates.get(0) : profile == 2 ? FpsEngine.pick(this, 60) : rates.get(rates.size() - 1);
        if (!FpsEngine.apply(this, target)) {
            status("Butuh izin Ubah setelan sistem. Izinkan lalu tekan APPLY lagi.", WARN);
            open(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + getPackageName())));
            return;
        }
        sp.edit().putInt("fps", target).apply();
        try {
            FpsEngine.prefer(bp, this, target); wm.updateViewLayout(bubble, bp);
            if (panel != null && pp != null) { FpsEngine.prefer(pp, this, target); wm.updateViewLayout(panel, pp); }
        } catch (Exception ignored) { }
        paintFps();
        status("Profil diterapkan • refresh rate " + target + " Hz", OK);
    }

    private void reflowForOrientation() {
        if (wm == null) return;
        int sw = getResources().getDisplayMetrics().widthPixels;
        int sh = getResources().getDisplayMetrics().heightPixels;
        int size = dp(54);
        if (bp != null && bubble != null && bubble.isAttachedToWindow()) {
            boolean right = bp.x + size / 2 >= sw / 2;
            bp.x = right ? Math.max(dp(4), sw - size - dp(4)) : dp(4);
            bp.y = Math.max(dp(8), Math.min(bp.y, sh - size - dp(8)));
            try { wm.updateViewLayout(bubble, bp); } catch (Exception ignored) { }
        }
        if (panel != null && pp != null) {
            int pw = Math.min(dp(340), sw - dp(20));
            int ph = Math.min((int)(sh * .78f), dp(650));
            pp.width = pw; pp.height = ph;
            pp.x = Math.max(dp(8), Math.min(pp.x, sw - pw - dp(8)));
            pp.y = Math.max(dp(8), Math.min(pp.y, sh - ph - dp(8)));
            barW = pw - dp(28);
            try { wm.updateViewLayout(panel, pp); } catch (Exception ignored) { }
        }
    }

    private void chooseGame() {
        PackageManager pm = getPackageManager(); Intent query = new Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER);
        java.util.List<ResolveInfo> apps = pm.queryIntentActivities(query, 0);
        java.util.Collections.sort(apps, (a,b) -> String.CASE_INSENSITIVE_ORDER.compare(a.loadLabel(pm).toString(), b.loadLabel(pm).toString()));
        java.util.ArrayList<String> labels = new java.util.ArrayList<>(), packages = new java.util.ArrayList<>();
        for (ResolveInfo ri : apps) { String pkg = ri.activityInfo.packageName; if (!pkg.equals(getPackageName()) && !packages.contains(pkg)) { labels.add(ri.loadLabel(pm).toString()); packages.add(pkg); } }
        if (labels.isEmpty()) { status("Tidak ada aplikasi untuk dipilih", WARN); return; }
        new AlertDialog.Builder(this).setTitle("Pilih game/aplikasi").setItems(labels.toArray(new String[0]), (d, which) -> { sp.edit().putString("saved_game_package", packages.get(which)).putString("saved_game_name", labels.get(which)).apply(); status("Tersimpan: " + labels.get(which), OK); }).setNegativeButton("BATAL", null).show();
    }
    private void startGameSession() {
        String pkg = sp.getString("saved_game_package", "");
        if (pkg.isEmpty()) { chooseGame(); return; }
        if (sp.getBoolean("thermal_guard", false)) {
            Intent b = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            float temp = b == null ? 0 : b.getIntExtra("temperature", 0) / 10f;
            if (temp >= 44f) { status("AUTO START ditahan Thermal Guard • " + temp + "°C", WARN); return; }
            if (temp >= 42f) status("Thermal Guard: suhu baterai tinggi • " + temp + "°C", WARN);
        }
        status("Menyiapkan sesi game…", WARN);
        applyRenderProfile();
        boost(0);
        ui.postDelayed(this::launchSavedGame, 1500);
    }

    private void launchSavedGame() {
        String pkg = sp.getString("saved_game_package", ""); if (pkg.isEmpty()) { chooseGame(); return; }
        Intent launch = getPackageManager().getLaunchIntentForPackage(pkg); if (launch == null) { status("Game tidak ditemukan. Pilih ulang.", WARN); return; }
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(launch);
    }

    private void setFps(final int target) {
        final int hz = FpsEngine.pick(this, target);
        if (!FpsEngine.apply(this, hz)) {
            if (!sp.getBoolean("write_settings_prompted", false)) {
                sp.edit().putBoolean("write_settings_prompted", true).apply();
                open(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + getPackageName())));
            } else status("Izin belum aktif. Aktifkan sekali dari Pengaturan aplikasi.", WARN);
            return;
        }
        sp.edit().putBoolean("write_settings_prompted", false).putInt("fps", target).apply();
        try {
            FpsEngine.prefer(bp, this, hz); wm.updateViewLayout(bubble, bp);
            if (panel != null && pp != null) { FpsEngine.prefer(pp, this, hz); wm.updateViewLayout(panel, pp); }
        } catch (Exception ignored) { }
        paintFps(); status("Menerapkan " + hz + " Hz…", WARN);
        ui.postDelayed(() -> { String m = FpsEngine.verify(this, target, hz); status(m, m.startsWith("✓") ? OK : WARN); }, 900);
    }
    private void awake(boolean on) { sp.edit().putBoolean("awake", on).apply(); applyAwake(); }
    private void applyAwake() {
        boolean on = sp.getBoolean("awake", false);
        for (WindowManager.LayoutParams p : new WindowManager.LayoutParams[]{bp, pp}) {
            if (p == null) continue;
            if (on) p.flags |= WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON; else p.flags &= ~WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
        }
        try {
            if (bubble != null && bubble.isAttachedToWindow()) wm.updateViewLayout(bubble, bp);
            if (panel != null && pp != null) wm.updateViewLayout(panel, pp);
        } catch (Exception ignored) { }
    }

    private long size(File f) { if (!f.exists()) return 0; if (f.isFile()) return f.length(); long n = 0; File[] a = f.listFiles(); if (a != null) for (File x : a) n += size(x); return n; }
    private void delete(File f) { if (!f.exists()) return; if (f.isDirectory()) { File[] a = f.listFiles(); if (a != null) for (File x : a) delete(x); } if (!f.equals(getCacheDir())) f.delete(); }

    @Override public int onStartCommand(Intent i, int flags, int id) {
        if (i != null && "STOP".equals(i.getAction())) { stopSelf(); return START_NOT_STICKY; }
        return START_STICKY;
    }
    @Override public void onDestroy() {
        running = false;
        try { unregisterReceiver(orientationReceiver); } catch (Exception ignored) { }
        ui.removeCallbacks(tick); meter.stop();
        try { if (bubble != null) wm.removeView(bubble); } catch (Exception e) { }
        try { if (panel != null) wm.removeView(panel); } catch (Exception e) { }
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent i) { return null; }
}
